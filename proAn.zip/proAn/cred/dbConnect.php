<?php
// Add mySQL math

// $path = str_replace('www', '', getcwd());
// system('"'.$path'mysql\bin\mysqld.exe"');

$username = "root";
$servername = "localhost";
$password = "";
$db = "pro_analysis";
$connect = mysqli_connect($servername, $username, $password, $db);

?>